-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2024 at 05:03 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `comcamp`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `O_ID` varchar(10) NOT NULL,
  `O_CID` varchar(100) NOT NULL,
  `O_EID` varchar(100) NOT NULL,
  `O_OD` varchar(200) NOT NULL,
  `O_SID` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_thai_520_w2;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`O_ID`, `O_CID`, `O_EID`, `O_OD`, `O_SID`) VALUES
('121322', '45454', '785452', 'eeeeeeeeeeeeeeeeeeeee', '4564565'),
('12888', '5', '76', 'sfr6', '456');

-- --------------------------------------------------------

--
-- Table structure for table `orders_detail`
--

CREATE TABLE `orders_detail` (
  `D_DID` varchar(20) NOT NULL,
  `D_ID` varchar(20) NOT NULL,
  `D_PID` varchar(20) NOT NULL,
  `D_QY` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_thai_520_w2;

--
-- Dumping data for table `orders_detail`
--

INSERT INTO `orders_detail` (`D_DID`, `D_ID`, `D_PID`, `D_QY`) VALUES
('OD001', 'O66001', 'P00125', '12'),
('OD002', 'O66002', 'P00124', '19'),
('q', 'wq', 'wqw', 'qwqwqeqewqe');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `P_ID` varchar(4) NOT NULL,
  `P_Name` varchar(500) NOT NULL,
  `P_SupID` varchar(100) NOT NULL,
  `P_CatID` varchar(100) NOT NULL,
  `P_Unit` varchar(500) NOT NULL,
  `P_Price` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_thai_520_w2;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`P_ID`, `P_Name`, `P_SupID`, `P_CatID`, `P_Unit`, `P_Price`) VALUES
('A001', 'น้ำแร่ธรรมชาติ', '2', '1', '12 ขวด', '48'),
('A100', 'น้ำมันพืช', '10', '4', 'ขวด', '48'),
('B001', 'ผักคะน้า', '5', '2', 'กิโลกรัม', '50'),
('B003', 'นมสด', '2', '3', '300 มล.', '24'),
('C001', 'หมูแดดเดียว', '9', '3', 'กรัม', '35'),
('D001', 'น้ำตาลทราย', '4', '4', 'กิโลกรัม', '22'),
('dfdf', 'dfdf', 'dfdfd', '1', '5555', 'd');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `S_ID` varchar(10) NOT NULL,
  `S_Name` varchar(500) NOT NULL,
  `S_Phone` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_thai_520_w2;

-- --------------------------------------------------------

--
-- Table structure for table `type_product`
--

CREATE TABLE `type_product` (
  `T_ID` varchar(4) NOT NULL,
  `T_Name` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_thai_520_w2;

--
-- Dumping data for table `type_product`
--

INSERT INTO `type_product` (`T_ID`, `T_Name`) VALUES
('1', 'เนื้อสัตว์'),
('2', 'ผัก-ผลไม้'),
('3', 'อาหารแห้ง'),
('4', 'เครื่องปรุง'),
('5', 'เครื่องดื่ม');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`O_ID`);

--
-- Indexes for table `orders_detail`
--
ALTER TABLE `orders_detail`
  ADD PRIMARY KEY (`D_DID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`P_ID`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`S_ID`);

--
-- Indexes for table `type_product`
--
ALTER TABLE `type_product`
  ADD PRIMARY KEY (`T_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
