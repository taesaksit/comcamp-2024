<?php
$y = json_decode(file_get_contents('php://input'));

$sql_cmd = "DELETE FROM `product` WHERE `P_ID` = '{$y->pn}';";

$conn = new mysqli("localhost", 'root', "", 'comcamp');
$sql_result = $conn->query($sql_cmd);

if($sql_result){
  echo json_encode(1); 
}else {
  echo json_encode(0); 
}

  $conn->close();
?>
