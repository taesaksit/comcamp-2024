<?php
$y = json_decode(file_get_contents('php://input'));

$sql_cmd = "SELECT * FROM `type_product`;";

$conn = new mysqli("localhost", 'root', "", 'comcamp');

$sql_result = $conn->query($sql_cmd);

$export = array();
while($rec = $sql_result->fetch_assoc() ){
    $export[] =$rec;
}
  echo json_encode($export);
  $conn->close();
?>
