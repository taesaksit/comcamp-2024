angular.module("ajboapp", [])
.controller("product_ctrl",['$scope','$http',
function($scope,$http){


$scope.senddata = function(){
    $http({method: 'post', 
           url: "insert_prg.php",
           data: $scope.f ,
           headers: {"Content-type": "application/x-www-form-urlencoded" }
    }).then(
        function(A){
            var myModal = new bootstrap.Modal(document.getElementById('staticBackdrop'), {
                keyboard: false
              });
              if(A.data == 1 ){
                $scope.bobo = "บันทึกสำเร็จจ้า";
                $scope.getdata();  
                $scope.f ={}; 
              }else{
                $scope.bobo = "ตายแล้วเธออ ไม่เก่งเลยอะ";
              }
            myModal.show();
        } , 
        function(B){}
    );
}

$scope.getdata = function(){
  if( $scope.search == undefined ){
    $scope.search={'key':''};
  }
  $http({method: 'post', 
         url: "select_prg.php",
         data: $scope.search ,
         headers: {"Content-type": "application/x-www-form-urlencoded" }
        })
  .then( 
        function(A){
          $scope.allproduct = A.data;
        } , 
        function(A){}
        );
}

$scope.deldata = function(will_be_deleted){
  $http({
    method:'post' ,
    url:"delete_prg.php",
    data: {pn : will_be_deleted}, 
    headers:{"Content_Type":"application/x-www-form-urlencoded"}

  }).then(
    function(A){
      var myModal = new bootstrap.Modal(document.getElementById('staticBackdrop'), {
        keyboard: false
        
      });
      if(A.data == 1){
        $scope.bobo = "ลบสำเร็จ";
      }else{
        $scope.bobo = "ลบไม่สำเร็จ";
      }
      myModal.show();
      $scope.getdata();
    },

    function(B){

    }
  );
}

$scope.delconfirm = function(will_be_deleted){
  $scope.delconf = will_be_deleted;
  var myModal = new bootstrap.Modal(document.getElementById('deleteconfirm'), {
    keyboard: false
  });
    myModal.show();
}

$scope.upse = function(will_be){
  $http({
    method:'post' ,
    url:"select_prg.php",
    data: {key : will_be}, 
    headers:{"Content_Type":"application/x-www-form-urlencoded"}

  }).then(
    function(A){
      $scope.xyz = A.data[0];
      var myModal = new bootstrap.Modal(document.getElementById('xyz'), {
        keyboard: false
        
      });
        myModal.show();
      },

    function(B){

    }
  );
}

$scope.update = function(){
        $http({method: 'post', 
               url: "update_prg.php",
               data: $scope.xyz,
               headers: {"Content-type": "application/x-www-form-urlencoded" }
              }).then(
                function(A){

                  var myModal = new bootstrap.Modal(document.getElementById('staticBackdrop'), {
                    keyboard: false
                    
                  });
                  if(A.data == 1){
                    $scope.bobo = "upสำเร็จ";
                  }else{
                    $scope.bobo = "upไม่สำเร็จ";
                  }
                    myModal.show();
                    $scope.getdata();
                  },
            
                function(B){
                }
              );
}

$scope.gettype = function(){
  $http({method: 'post', 
         url: "select_type_prg.php",
         data: null ,
         headers: {"Content-type": "application/x-www-form-urlencoded" }
        })
  .then( 
        function(A){
          $scope.alltype = A.data;
        } , 
        function(A){}
        );
}

$scope.showchart = function(){

  $http({method: 'post', 
    url: "chart.php",
    data: null ,
    headers: {"Content-type": "application/x-www-form-urlencoded" }
   }).then( 
    function(A){
      const ctx = document.getElementById('myChart');
      new Chart(ctx, {
        type: 'bar',
        data: {
          labels: A.data[0],
          datasets: [{
            label: '',
            data: A.data[1],
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });

    } , 
    function(A){}
    );


}

}]);