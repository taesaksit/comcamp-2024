<?php
$y = json_decode(file_get_contents('php://input'));


$sql_cmd = "SELECT T_Name, count(P_ID) as num 
FROM `product` inner join type_product on (product.P_CatID =  type_product.T_ID)
GROUP BY T_Name;";

$conn = new mysqli("localhost", 'root', "", 'comcamp');

$sql_result = $conn->query($sql_cmd);

$label = array();
$data = array();
while($rec = $sql_result->fetch_assoc() ){
    $label[] = $rec['T_Name'];
    $data[]  = $rec['num'];
}
echo json_encode([$label,$data]);
$conn->close();
?>
