<?php
$y = json_decode(file_get_contents('php://input'));


$sql_cmd = "SELECT P_ID,P_Name ,P_SupID,  P_CatID ,type_product.T_Name,P_Unit,P_Price 
FROM `product` inner join type_product on (product.P_CatID =  type_product.T_ID)
WHERE 
    P_Name LIKE '%{$y->key}%' OR
    P_ID LIKE '%{$y->key}%' OR
    P_SupID LIKE '%{$y->key}%' OR
    P_CatID LIKE '%{$y->key}%' OR
    P_Unit LIKE '%{$y->key}%' OR
    P_Price LIKE '%{$y->key}%' OR
    T_Name LIKE '%{$y->key}%';";

/* $sql_cmd = "SELECT * FROM `product` 
WHERE 
    P_Name LIKE '%{$y->key}%' OR
    P_ID LIKE '%{$y->key}%' OR
    P_SupID LIKE '%{$y->key}%' OR
    P_CatID LIKE '%{$y->key}%' OR
    P_Unit LIKE '%{$y->key}%' OR
    P_Price LIKE '%{$y->key}%';"; */

$conn = new mysqli("localhost", 'root', "", 'comcamp');

$sql_result = $conn->query($sql_cmd);

$export = array();
while($rec = $sql_result->fetch_assoc() ){
    $export[] =$rec;
}
    echo json_encode($export);
   $conn->close();
?>
