<?php
$y = json_decode(file_get_contents('php://input'));

$sql_cmd = "UPDATE `product` SET `P_ID`='{$y->P_ID}',`P_Name`='{$y->P_Name}',
                           `P_SupID`='{$y->P_SupID}',`P_CatID`='{$y->P_CatID}',
                           `P_Unit`='{$y->P_Unit}',`P_Price`='{$y->P_Price}'
WHERE 
    P_ID LIKE '%{$y->P_ID}%';";


$conn = new mysqli("localhost", 'root', "", 'comcamp');
$sql_result = $conn->query($sql_cmd);

if($sql_result){
  echo json_encode(1); 
}else {
  echo json_encode(0); 
}

  $conn->close();
?>
