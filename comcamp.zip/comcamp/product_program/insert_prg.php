<?php
$y = json_decode(file_get_contents('php://input'));

$sql_cmd = "INSERT INTO `product` (`P_ID`, `P_Name`, `P_SupID`, `P_CatID`, `P_Unit`, `P_Price`) 
           VALUES ('{$y->a}', '{$y->b}', '{$y->c}', '{$y->d}', '{$y->e}', '{$y->f}');";  

$conn = new mysqli("localhost", 'root', "", 'comcamp');
$sql_result = $conn->query($sql_cmd);

if($sql_result){
  echo json_encode(1); 
}else {
  echo json_encode(0); 
}

  $conn->close();
?>
